export { generateTheme } from './generator'
