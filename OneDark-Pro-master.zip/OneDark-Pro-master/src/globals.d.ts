declare module '*.md'
