export interface Colors {
  chalky: string
  coral: string
  dark: string
  error: string
  fountainBlue: string
  green: string
  invalid: string
  lightDark: string
  lightWhite: string
  malibu: string
  purple: string
  whiskey: string
}
