export interface ThemeConfiguration {
  bold?: boolean
  italic?: boolean
  vivid?: boolean
  editorTheme?: string
}
